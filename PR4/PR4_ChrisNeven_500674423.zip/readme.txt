Student: Chris Neven 
Studentnummer: 500674423
Docent: Tim Visser
Klas: SE201
Datum: 25 december 2018


Welkom bij practicum 4 opdracht van het vak testen. Het doel van deze opdracht is om mijn kennis en vaardigheden van het automatisch end-to-end testen van User Interfaces te verbreden en te verdiepen. Ik heb hiervoor Kantu-IDE gebruikt. Als usecase voor het practicum is een van mijn dagelijks bezochte websites gebruikt, namelijk: http://www.voetbalprimeur.nl. De naam zegt hopelijk genoeg over het onderwerp van de website.

Instructies:

1. 	Zorg ervoor dat Kantu voor Chrome geïnstalleerd is.
2. 	Importeer alle macro's uit de macros folder in Kantu
3. 	Vervolgens importeer je het suite_Voetbalprimeur.json bestand als testsuite in 		Kantu
4. 	Importeer ook het newinfo.csv bestand bij de csv's van Kantu. Hier staan clubs in 	en kan eventueel een club aan worden toegevoegd of verwijderd. Als je er een 		wijzigt/toevoegt zorg ervoor dat de club bestaat op voetbalprimeur, anders werkt 	het niet.
5. 	Zorg dat een tabblad/window van Chrome gelinkt is aan Kantu
6. 	Klik dan met je rechtermuisknop op TESTSUITE_Voetbalprimeur in Kantu
7. 	De tests worden gerund

