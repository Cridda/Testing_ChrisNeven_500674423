package nl.trifork.bank.accountms.model;

public enum Role {
    USER, ADMIN;
}

