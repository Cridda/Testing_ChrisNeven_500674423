import { AccommodationFeatureResolvers } from '../generated/graphqlgen';

export const AccommodationFeature: AccommodationFeatureResolvers.Type = {
    ...AccommodationFeatureResolvers.defaultResolvers
};
