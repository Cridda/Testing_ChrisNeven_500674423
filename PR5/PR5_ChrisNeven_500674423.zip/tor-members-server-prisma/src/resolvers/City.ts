import { CityResolvers } from '../generated/graphqlgen';

export const City: CityResolvers.Type = {
    ...CityResolvers.defaultResolvers
};
