import { SiteResolvers } from '../generated/graphqlgen';

export const Site: SiteResolvers.Type = {
    ...SiteResolvers.defaultResolvers
};
