import { TranslatableStringResolvers } from '../generated/graphqlgen';

export const TranslatableString: TranslatableStringResolvers.Type = {
    ...TranslatableStringResolvers.defaultResolvers
};
