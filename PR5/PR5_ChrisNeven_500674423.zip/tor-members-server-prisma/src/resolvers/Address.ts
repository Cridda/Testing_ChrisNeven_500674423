import { AddressResolvers } from '../generated/graphqlgen';

export const Address: AddressResolvers.Type = {
    ...AddressResolvers.defaultResolvers
};
