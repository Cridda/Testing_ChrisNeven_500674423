import { AccommodationTypeResolvers } from '../generated/graphqlgen';

export const AccommodationType: AccommodationTypeResolvers.Type = {
    ...AccommodationTypeResolvers.defaultResolvers
};
