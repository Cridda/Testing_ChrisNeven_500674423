// This resolver file was scaffolded by github.com/prisma/graphqlgen, DO NOT EDIT.
// Please do not import this file directly but copy & paste to your application code.

import { BedroomResolvers } from "../graphqlgen";

export const Bedroom: BedroomResolvers.Type = {
  ...BedroomResolvers.defaultResolvers,

  name: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  type: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  }
};
