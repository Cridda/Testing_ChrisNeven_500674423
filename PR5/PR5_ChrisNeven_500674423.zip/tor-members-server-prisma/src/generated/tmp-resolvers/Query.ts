// This resolver file was scaffolded by github.com/prisma/graphqlgen, DO NOT EDIT.
// Please do not import this file directly but copy & paste to your application code.

import { QueryResolvers } from "../graphqlgen";

export const Query: QueryResolvers.Type = {
  ...QueryResolvers.defaultResolvers,
  me: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  accommodation: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  sites: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  features: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  bedroomTypes: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  bathroomTypes: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  accommodations: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  users: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  }
};
