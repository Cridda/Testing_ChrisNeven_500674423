// This resolver file was scaffolded by github.com/prisma/graphqlgen, DO NOT EDIT.
// Please do not import this file directly but copy & paste to your application code.

import { TranslatableStringResolvers } from "../graphqlgen";

export const TranslatableString: TranslatableStringResolvers.Type = {
  ...TranslatableStringResolvers.defaultResolvers
};
