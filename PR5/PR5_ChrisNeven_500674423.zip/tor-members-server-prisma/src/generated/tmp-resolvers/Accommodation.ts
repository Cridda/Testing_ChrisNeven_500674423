// This resolver file was scaffolded by github.com/prisma/graphqlgen, DO NOT EDIT.
// Please do not import this file directly but copy & paste to your application code.

import { AccommodationResolvers } from "../graphqlgen";

export const Accommodation: AccommodationResolvers.Type = {
  ...AccommodationResolvers.defaultResolvers,

  type: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  city: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  description: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  keyAddress: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  address: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  sites: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  features: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  bathrooms: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  bedrooms: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  },
  photos: (parent, args, ctx) => {
    throw new Error("Resolver not implemented");
  }
};
