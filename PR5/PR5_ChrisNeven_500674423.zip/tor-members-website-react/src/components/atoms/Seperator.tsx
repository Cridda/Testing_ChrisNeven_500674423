import styled from 'styled-components';
export const Seperator = styled.div`
    width: 1px;
    height: 4.8rem;
    align-self: center;
    background-color: #122e3f; /* verwerken in theme colors */
`;
