import React from 'react';

export const Loading = () => <div>Loading...</div>;
