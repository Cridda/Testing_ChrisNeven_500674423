# TOR-members-website-react

The front-end for the TOR-members application.

## Prerequisites

-   [TOR-members-server-prisma](https://bitbucket.org/cridda/tor-members-server-prisma) running (TODO: setup remotely)
-   Yarn or npm installed

## Get started

1. Install dependecies: `npm install`
2. Start TOR-members: `npm start`
3. TOR-members runs at: <http://localhost:3000>
